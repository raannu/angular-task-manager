import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';

import {TaskService } from './services/task.service';
import { AuthGuard } from './guards/auth.guard';
import { MessageService } from './services/message.service';

import { AppComponent } from './app.component';
import { LoginFromComponent } from './component/login-from/login-from.component';
import { HeaderComponent } from './component/shared/header/header.component';
import { FooterComponent } from './component/shared/footer/footer.component';
import { RegisterFromComponent } from './component/register-from/register-from.component';
import { TaskManagerComponent } from './component/task-manager/task-manager.component';
import { TaskFromComponent } from './component/task-manager/task-from/task-from.component';
import { TaskListComponent } from './component/task-manager/task-list/task-list.component';
import { TaskItemComponent } from './component/task-manager/task-item/task-item.component';
import { PageNotFoundComponent } from './component/shared/page-not-found/page-not-found.component';
import { TaskDetailComponent } from './component/task-manager/task-detail/task-detail.component';
import { MyUppercasePipe } from './pipes/my-uppercase.pipe';
import { SearchPipe } from './pipes/search.pipe';
import { TaskCompletedDirective } from './directives/task-completed.directive';
import { HighlightDirective } from './directives/highlight.directive';

const routes: Routes = [
  {path:'', redirectTo: '/login', pathMatch:'full'},
  {path: 'login', component: LoginFromComponent},
  {path: 'register', component: RegisterFromComponent },
  {path: 'tasks', component: TaskManagerComponent, canActivate:[AuthGuard]},
  {path: 'tasks/detail/:id', component:TaskDetailComponent, canActivate:[AuthGuard]},
  {path: '**', component: PageNotFoundComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    LoginFromComponent,
    HeaderComponent,
    FooterComponent,
    RegisterFromComponent,
    TaskManagerComponent,
    TaskFromComponent,
    TaskListComponent,
    TaskItemComponent,
    PageNotFoundComponent,
    TaskDetailComponent,
    MyUppercasePipe,
    SearchPipe,
    TaskCompletedDirective,
    HighlightDirective
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [ TaskService, AuthGuard, MessageService ],
  
  bootstrap: [AppComponent]

})
export class AppModule { }
