import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-from',
  templateUrl: './login-from.component.html',
  styleUrls: ['./login-from.component.css']
})
export class LoginFromComponent implements OnInit {

  model: any = {};

  constructor(private router: Router) { }

  ngOnInit() {
    localStorage.removeItem('user');
  }
  login(form){
    // actually we would like to send a post request to the server
    if(this.model.username === 'admin' && this.model.password === 'admin'){
      localStorage.setItem('user', this.model.username);
      // redirect to the task manager
      this.router.navigate(['/tasks']);
    }else{
      // show an error
      
    }  
  }
}
