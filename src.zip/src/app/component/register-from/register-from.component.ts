import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';

import { symbolValidator, passwordMatch } from '../../../helpers/validation';

@Component({
  selector: 'app-register-from',
  templateUrl: './register-from.component.html',
  styleUrls: ['./register-from.component.css']
})
export class RegisterFromComponent implements OnInit {

  registerForm: FormGroup;

  constructor(private builder: FormBuilder) { }

  ngOnInit() {
    // this.registerForm = new FormGroup({      
    //   name: new FormControl(''),
    //   email: new FormControl(''),
    //   password: new FormControl(''),
    //   confirmPassword: new FormControl('')
    // })
    this.buildForm();
  }

  buildForm(){
    this.registerForm = this.builder.group({
      name:['', Validators.required],
      email:['', Validators.compose([Validators.required,Validators.email])],
      password:['', Validators.compose([Validators.required, symbolValidator])],
      confirmPassword:''
    },{
      validator: passwordMatch
    });
  }
}
