import { Component, OnInit } from '@angular/core';
import { TaskService } from '../../../services/task.service';
import { MessageService } from '../../../services/message.service';

@Component({
  selector: 'app-task-from',
  templateUrl: './task-from.component.html',
  styleUrls: ['./task-from.component.css']
})
export class TaskFromComponent implements OnInit {
  taskTitle: string = '';
  constructor(private taskService: TaskService,
  private messageService: MessageService 
) { }

  ngOnInit() {
  }

  addTask(){
    this.taskService.addTask(this.taskTitle).subscribe((data) =>{
      this.taskTitle = '';
      this.messageService.setMessage('Task Added Successfully');
    })

    return false;
  }
}
