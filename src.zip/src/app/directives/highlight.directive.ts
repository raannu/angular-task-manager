import { Directive, ElementRef, HostListener } from '@angular/core';
import { hostElement } from '../../../node_modules/@angular/core/src/render3/instructions';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective{

  constructor(private el:ElementRef) { }

 

  @HostListener('mouseenter') onmouseenter(){
    this.el.nativeElement.style.backgroundColor = 'yellow';
  }

  @HostListener('mouseout') onmouseleave(){
    this.el.nativeElement.style.backgroundColor = 'white';
  }
}
