import { TaskCompletedDirective } from './task-completed.directive';

describe('TaskCompletedDirective', () => {
  it('should create an instance', () => {
    const directive = new TaskCompletedDirective();
    expect(directive).toBeTruthy();
  });
});
