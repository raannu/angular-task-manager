import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Task } from '../models/task';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class TaskService {
  //tasks: Task[] = [];
  // apiUrl: string = 'https://jsonplaceholder.typicode.com/todos';
    apiUrl: string = 'http://localhost:3000/tasks/';

    private headers = new Headers({'Content-Type':'application/json'});

  constructor(private http: HttpClient) { }

  getTasks(): Observable<Task[]> {
    return this.http.get<Task[]>(this.apiUrl);
  }
  getSingleTask(id: number): Observable<Task>{
    return this.http.get<Task>(this.apiUrl + '/' + id)
  }

  addTask(title: string) {

     const taskObj = {
       
       title, // title: title
       completed: false,
       date:new Date()
     }
    return this.http.post<Task>(this.apiUrl , taskObj);
  }

  removeTask(id: number): Observable<any> {
     return this.http.delete<Task>(this.apiUrl + '/' + id);
     }

   
  }

