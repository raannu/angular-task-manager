import { AbstractControl, FormGroup } from '@angular/forms';

export function symbolValidator(el: AbstractControl){
    // return an onject if there is error (if there is no symbol used in the password)
    if(el.value.indexOf('@')=== -1){
        return{
            symbol: true
        }
    }
    // return null if there is no erro (if there is @ symbol)
    return null;
}

export function passwordMatch(form: FormGroup){
    const password = form.get('password');
    const confirmPassword = form.get('confirmPassword');
    if(password.value === confirmPassword.value){
        confirmPassword.setErrors(null);
    }else{
        confirmPassword.setErrors({
            passwordMatch:true
        })
    }
    return null;
}